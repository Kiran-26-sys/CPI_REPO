import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {

    def xml = new XmlSlurper().parse(message.getBody(java.io.Reader))

    def responses = xml.message.drop(1).collect {
        it.response.text().trim()
    }

    def result = responses.join("\n\n")

    // Escape JSON special characters
    result = result
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\r", "")
            .replace("\n", "\\n")
            .replace("\t", "\\t")

    message.setBody(result)

    return message
}