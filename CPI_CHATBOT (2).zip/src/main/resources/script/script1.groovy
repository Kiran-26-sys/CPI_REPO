import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def json = new JsonSlurper().parse(message.getBody(java.io.Reader))

    def response = json.candidates[0].content.parts[0].text

    message.setBody(response)

    return message
}
``